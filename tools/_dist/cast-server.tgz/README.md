# 授权服务器（webvr123.site）

EXE 直播端的商业化授权：签发 license、按 15 天续期、可远程吊销。
方案全文见 `docs/tech/08-授权服务器与License方案.md`。

**当前实现状态**

| 段 | 状态 |
|---|---|
| 服务器（本目录） | ✅ 已完成，33 项自测全通过 |
| EXE 接入（`tools/cast-pc`） | ⬜ 待做（P2） |
| 头显接入（`tools/cast-apk`） | ⬜ 待做（P3） |

在 P2/P3 完成之前，两端仍走第十七修的「固定密钥 + 配对窗口」，**不影响现有现场使用**。

---

## 1. 三层结构

```
① webvr123.site（本目录）  用 Ks 私钥签发 license
        ↓ license（含 EXE 实例公钥 ke + 到期时间 exp）
② EXE 直播端（PC）         本地存 license；向头显出示 license + 用 Ke 私钥签的 proof
        ↓ license + proof（局域网，明文可传）
③ 头显 APK                内置 Ks_pub 验 license 签名；用 license 里的 ke 验 proof
```

**为什么这样设计**：license 原文要出示给头显看，在局域网里明文传输。若只是一份静态凭据，
**任何拿到原文的人都能原样转发**。所以凭据里绑了一把**只属于那台 EXE 的密钥**（`ke`），
出示时要求 EXE 用对应私钥签一个**头显当场给的随机数**。

→ 结果：license 可以随便复制，但没有那把私钥就签不出新鲜证明。**整个方案不依赖代码保密**
（打包后的 EXE 可以被完整反编译，只要拿不到两把私钥就伪造不出任何东西）。

---

## 2. 一次性初始化（顺序不能错）

> **走 §3.2 的一键脚本时，这一步不用手动做** —— 脚本会在服务器上自动生成密钥与管理员凭证。
> 本地执行只用于离线测试（跑 `selftest.js`、`xlang/`）。
> ⚠️ 若本地生成了却没上传，服务器会另外生成一套 —— 两套的**公钥不是同一对**，
> 硬编码进两端时必须用服务器那一套（脚本会打印指纹与内容）。

```bash
cd tools/cast-server
node gen-keys.js
```

会生成三个文件（`secrets/`，已进 `.gitignore`）：

| 文件 | 用途 |
|---|---|
| `license-sign.pem` | 🔴 **签发私钥 Ks**。只在服务器上，权限 600 |
| `license-pub.pem` | 🟢 公钥 PEM |
| `public-key.txt` | 🟢 一行 base64 —— **就是要硬编码进 EXE 与 APK 的那串** |

### ⚠️ 立刻做两件事

1. **离线备份 `secrets/license-sign.pem`**（U 盘 / 另一台机器）。
   丢了 = **所有已发 license 都没法续期**，只能重新生成密钥对并**发新版 EXE 和 APK**。
   在门店已铺开的情况下，这是最贵的一次事故。
2. 把 `public-key.txt` 的内容抄进 `tools/cast-pc/main.js` 与
   `tools/cast-apk/.../MainActivity.java` 的 `LICENSE_PUBKEY_B64`（P2/P3 时做）。

> 私钥**绝不能**进 git、**绝不能**打进 EXE。反过来，公钥是公开的，反编译出来毫无价值。

---

## 3. 部署

### 3.1 上传代码（在你自己的电脑上）

只传代码，**不传 `data/`**（那是本地自测数据）。

```powershell
# Windows PowerShell
cd E:\AI_Work\WebXR_Begain\tools\cast-server
tar -czf "$env:TEMP\cast-server.tgz" --exclude=data --exclude=node_modules --exclude=.git --exclude=secrets .
scp "$env:TEMP\cast-server.tgz" root@<服务器IP>:/tmp/
```

> **`--exclude=secrets` 是推荐做法**：让服务器自己生成签发密钥，私钥从诞生起就只在
> `/opt/webvr123/secrets/`，不经过你的电脑、不经过网络传输。
> 若想沿用本地那一对（已备份、已过跨语言验证），**去掉这个参数** ——
> 脚本检测到密钥已存在会保留、绝不覆盖。
>
> 两种做法只能选一种。**混用会让两端硬编码的公钥与服务器私钥对不上，
> 现象是"永远验签失败"，且因为 ECDSA 每次签名都不同，极难定位。**

### 3.2 一键安装（在服务器上）

```bash
sudo mkdir -p /opt/webvr123
sudo tar -xzf /tmp/cast-server.tgz -C /opt/webvr123
sudo bash /opt/webvr123/deploy/install.sh
```

脚本做 10 件事，**可反复执行**（幂等，升级代码后重跑同一句即可）：

| 步 | 动作 |
|---|---|
| 0 | 检查 root / 是否 Debian 系 / 代码是否完整 |
| 1 | 装 curl、gnupg、rsync |
| 2 | 检查 Node：≥22 直接用；18~21 能用但存储降级；<18 或没有 → 从 NodeSource 装 22 |
| 3 | 装 Caddy |
| 4 | 端口占用检查：发现 nginx 等占着 80/443 → 告警并提示用 `TAKEOVER=1` 接管；本机 `8787` 被别的进程占用时**只告警、不杀**（要杀得显式给 `KILL_PORT=1`） |
| 5 | 建系统用户 `webvr123`（无登录权限）+ 同步代码到 `/opt/webvr123` |
| 6 | 生成签发密钥 `Ks` 与管理员凭证（**已存在则保留，绝不覆盖**） |
| 7 | 装 systemd 服务，`ExecStart` 自动改写成实际 node 路径 |
| 8 | 写 Caddyfile（已有其它站点时**备份但不覆盖**，除非 `FORCE_CADDY=1`） |
| 9 | ufw 放行 80/443（8787 不对外） |
| 10 | 起服务 + 本机健康检查 + DNS 比对 + HTTPS 自测 |

跑完打印的总结块里有 **公钥指纹 + 公钥内容**，那两行就是要抄进 EXE / APK 的。

常用覆盖项：

```bash
DOMAIN=webvr123.site APP_DIR=/opt/webvr123 PORT=8787 sudo bash deploy/install.sh
FORCE_NODE=1  sudo bash deploy/install.sh   # 已有 Node 18~21 时强行升到 22
FORCE_CADDY=1 sudo bash deploy/install.sh   # 覆盖已有 Caddyfile（会先备份）
TAKEOVER=1    sudo bash deploy/install.sh   # 停用占着 80/443 的 nginx，交给 Caddy
PORT=8788     sudo bash deploy/install.sh   # 8787 被占时换个内部端口（零风险，首选）
KILL_PORT=1   sudo bash deploy/install.sh   # 确认可结束时，才结束占用 8787 的进程
```

### 3.2.1 若服务器上已经跑着别的网站（nginx / 宝塔）

很多 VPS 到手时 80 / 443 已经被 nginx 占着 —— 这时 **Caddy 起不来、证书也申请不到**。
脚本第 4 步会探测并告警，但**默认不动它**（避免误伤别人的站点）。

确认可以停掉它之后，加 `TAKEOVER=1` 重跑：

```bash
TAKEOVER=1 sudo bash /opt/webvr123/deploy/install.sh
```

`TAKEOVER=1` 只做三件事，**全部可逆**：

| 动作 | 影响 |
|---|---|
| `systemctl stop` + `disable nginx` | 只停服务，`/etc/nginx` 与网站文件**原样保留**；恢复：`systemctl enable --now nginx` |
| 停用 certbot 续期定时器 | 证书改由 Caddy 申请与续期，避免两边抢 80 端口 |
| ~~结束占用 `$PORT` 的进程~~ | **已移出 `TAKEOVER`** —— 那属于「破坏性动作」，改由 `KILL_PORT=1` 单独授权；默认只告警并建议 `PORT=8788` |

脚本会顺手打印**原网站目录**（从 nginx 配置里解析），方便你回头找它。
原站点若哪天要恢复，把 nginx 装回来即可 —— 我们从未删过它的文件。

### 3.3 依赖

**零 npm 依赖** —— 不用 `npm install`。只需要：

| 组件 | 版本要求 | 说明 |
|---|---|---|
| Node.js | ≥ 18 | 推荐 **22+**（有内置 `node:sqlite`）；18/20 会自动降级为 JSON 文件存储，功能一样 |
| Caddy | 任意近期版本 | 自动 HTTPS |

### 3.4 手动部署（脚本不合用时照做）

```bash
# 目录与用户
sudo useradd -r -s /usr/sbin/nologin webvr123
sudo mkdir -p /opt/webvr123/data
sudo chown -R webvr123:webvr123 /opt/webvr123
sudo chmod 700 /opt/webvr123/secrets
sudo chmod 600 /opt/webvr123/secrets/license-sign.pem

# systemd（ExecStart 里的 node 路径按 `command -v node` 的实际值改）
sudo cp deploy/webvr123.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now webvr123
systemctl status webvr123          # 应为 active (running)
sudo journalctl -u webvr123 -n 40  # 看启动日志

# HTTPS（webvr123.site 的 A 记录须已指向本机，80/443 放行）
sudo cp deploy/Caddyfile /etc/caddy/Caddyfile
sudo systemctl reload caddy
```

> ⚠️ 手动部署**必须先建好 `data/` 并先生成 `secrets/admin.json`**：
> systemd 单元用了 `ProtectSystem=strict`，服务对 `/opt/webvr123` **只读**，只放开 `data/`。
> 缺 `data/` 目录 systemd 直接拒绝启动；缺 `admin.json` 则服务首次启动时写盘失败。
> 想省掉这一串，直接用 §3.2 的脚本。

### 3.5 自测

```bash
curl https://webvr123.site/api/health
# {"ok":true,"server":...,"store":"sqlite","licenses":0,...,"ttlDays":15,...}
```

管理员凭证在 `/opt/webvr123/secrets/admin.json`（安装脚本也会在总结里再打印一次）：

```bash
node -e "const j=require('/opt/webvr123/secrets/admin.json');console.log(j.user,j.pass)"
```

---

## 4. 日常运营

打开 `https://webvr123.site/admin`，浏览器会弹 Basic Auth，填第 3.3 步拿到的账号密码。

| 操作 | 说明 |
|---|---|
| **生成激活码** | 填客户标识 → 得到形如 `ABCD-EFGH-JKLM` 的码。交给运营商，在直播端填入完成激活 |
| **License 列表** | 看每台的到期时间、剩余天数、续期次数；一眼看出谁快过期 |
| **吊销** | 某台不再合作时点一下。它下次启动会被拒绝（**不是即时生效**，最长等一个心跳周期） |
| **手工签发** | 不走激活码，直接给一套 `dev`/`ke` 签发（调试或特殊情况用） |

### 建议的运营节奏

- license 有效期 **15 天**，EXE 会在**到期前 3 天**开始每 6 小时自动续期 → 正常情况下你什么都不用做。
- 每周扫一眼后台的「剩余天数」，有 < 7 天的说明那台机器续期连线有问题，需要联系现场排查。

---

## 5. 接口速查

| 方法 | 路径 | 调用方 | 鉴权 |
|---|---|---|---|
| GET | `/api/health` | 监控 | 无 |
| POST | `/api/license/activate` | EXE 首次 | 激活码 |
| POST | `/api/license/renew` | EXE 周期 | `Ke` 签名 proof |
| GET | `/api/license/revoked` | EXE 周期 | `Ke` 签名 proof |
| POST | `/api/license/issue` | 后台 | Basic Auth |
| POST | `/api/license/revoke` | 后台 | Basic Auth |
| GET | `/api/admin/licenses` | 后台 | Basic Auth |
| GET | `/api/admin/activations` | 后台 | Basic Auth |
| POST | `/api/admin/activation` | 后台 | Basic Auth |

proof 的签名对象（都是 ASCII 文本）：

```
续期：  "renew|<lic>|<ts>"        EXE 用 Ke 私钥签
吊销：  "revoked|<lic>|<ts>"      EXE 用 Ke 私钥签
出示：  "cast|<nonce>"            EXE 用 Ke 私钥签（P3 用，头显给 nonce）
```

`ts` 为毫秒时间戳，服务器容忍 ±5 分钟偏差 —— **两端都要开 NTP**。

### 错误码

| reason | 含义 | 现场处理 |
|---|---|---|
| `badCode` / `codeUsed` / `codeExpired` | 激活码无效/用尽/过期 | 后台重新生成一个 |
| `machineMismatch` | 机器指纹变了（换硬件） | 需重新激活 |
| `keyMismatch` | EXE 实例密钥被换过 | 需重新激活 |
| `badProof` | 持有证明验不过 | 不是被签的那台机；查是否拷贝了 license |
| `stale` | 时间偏差超 5 分钟 | 校时 |
| `revoked` | 已吊销 | 商业决定，恢复需在后台点「恢复」 |
| `rateLimit` | 尝试过于频繁 | 等 1 分钟 |

---

## 6. 调参

不用改代码，写 `config.json` 覆盖即可：

```json
{
  "port": 8787,
  "host": "127.0.0.1",
  "ttlDays": 15,
  "renewWindowDays": 3,
  "maxBody": 65536,
  "activateRatePerMin": 10,
  "renewRatePerMin": 60
}
```

| 参数 | 含义 | 备注 |
|---|---|---|
| `ttlDays` | license 有效期（天） | 需求方口述的「管 15 天」 |
| `renewWindowDays` | 到期前几天开始允许续期 | 客户端也按此判断，服务器只做上限校验 |
| `activateRatePerMin` | 单 IP 每分钟激活尝试上限 | 防爆破激活码 |
| `renewRatePerMin` | 单 IP 每分钟续期上限 | **必须与激活分开计数**，否则正常续期会被激活限流误伤 |

---

## 7. 自测与跨语言验证

```bash
node selftest.js
```

起一个临时服务（独立数据目录，不碰生产数据）跑 33 项：激活 / 幂等 / 错误码 /
续期 + proof 验签 / 时间偏差 / 换机 / 吊销 / 鉴权 / 限流 / 存储降级。

### 跨语言验签（改签名相关代码后必跑）

`xlang/` 里放着一套 Node 签 → Java 验的对照工具。**两端算法一旦对不齐，
现象是「永远验不过」，而且因为 ECDSA 每次签名都不同，没法用固定样本比对，极难定位** —— 所以改完密码学代码先跑它：

```bash
# 1) Node 生成样本
cd tools/cast-server && node xlang/gen.js
# 2) Java 按头显的方式验
cd tools/cast-server/xlang && \
  "C:/Program Files/Java/jdk-17/bin/java.exe" -Dfile.encoding=UTF-8 VerifyLicense.java
```

期望输出：正常 license「验签通过」，篡改 payload / 篡改签名 / 换公钥三项都「验签不通过」。

---

## 8. 排障

| 现象 | 原因 | 处理 |
|---|---|---|
| 起不来，日志 `找不到 secrets/license-sign.pem` | 没跑 `node gen-keys.js` | 跑它 |
| `EADDRINUSE` | 8787 被占 | 改 `config.json` 的 `port`，同步改 Caddyfile |
| Caddy 拿不到证书 | DNS 没指过来 / 80 端口没放行 | `dig webvr123.site` 确认 |
| 某台机器每次都要重新激活 | `dev` 机器指纹不稳定 | 见方案 §11.3，采集方式要经得起换网线/重启 |
| 大量 `stale` | 服务器或现场机器没校时 | 两边都开 NTP |
| 门店说「授权已到期」但后台显示有效 | 现场网络不通，续期没连上 | 检查现场出口防火墙是否放行 443 |

**日志**：`sudo journalctl -u webvr123 -f`，同时落盘 `data/server.log`。

---

## 9. 安全须知

- `secrets/` 与 `data/` 都在 `.gitignore` 里，**别手动加进版本库**。
- 私钥权限保持 `600`；`data/license.db` 含客户信息，也要限制读取。
- 服务器只监听 `127.0.0.1`，外部一律经 Caddy 的 HTTPS。
- **备份策略**：`data/` 每天拷一次；`secrets/license-sign.pem` 离线保存且**不进任何自动化备份链路**（避免私钥落到云盘）。
